git 软件安装
yum install -y git

外地校区
git clone git://43.254.90.134/nsd1902.git

北京本地
git clone git://172.40.53.65/nsd1902.git

更新(必须进入 git 目录)
git pull
